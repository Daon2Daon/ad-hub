# 프로젝트 구조 가이드

## 📋 목차

1. [프로젝트 개요](#프로젝트-개요)
2. [전체 파일 구조](#전체-파일-구조)
3. [애플리케이션(App) 컨테이너 구조](#애플리케이션app-컨테이너-구조)
4. [데이터베이스(PostgreSQL) 컨테이너 구조](#데이터베이스postgresql-컨테이너-구조)
5. [Docker 컨테이너 개별 업데이트](#docker-컨테이너-개별-업데이트)
6. [주요 설정 파일 설명](#주요-설정-파일-설명)

---

## 🎯 프로젝트 개요

**ad-hub**은 Next.js 15 기반의 광고 캠페인 관리 시스템입니다.

- **프레임워크**: Next.js 15 (App Router)
- **언어**: TypeScript
- **데이터베이스**: PostgreSQL 15
- **ORM**: Prisma
- **인증**: NextAuth.js
- **스타일링**: Tailwind CSS + Shadcn UI
- **컨테이너화**: Docker Compose

---

## 📁 전체 파일 구조

```
ad-hub/
├── src/                          # 소스 코드
│   ├── app/                      # Next.js App Router 페이지
│   │   ├── api/                  # API 라우트
│   │   ├── dashboard/            # 대시보드 페이지
│   │   ├── login/                # 로그인 페이지
│   │   ├── management/           # 캠페인 관리 페이지
│   │   ├── masterdata/           # 마스터 데이터 페이지
│   │   ├── logs/                 # 활동 로그 페이지
│   │   ├── report/               # 리포트 페이지
│   │   ├── schedule/             # 스케줄 페이지
│   │   ├── system/               # 시스템 설정 페이지
│   │   ├── layout.tsx            # 루트 레이아웃
│   │   └── page.tsx              # 홈 페이지
│   ├── components/               # React 컴포넌트
│   │   ├── auth/                 # 인증 관련 컴포넌트
│   │   ├── dashboard/             # 대시보드 컴포넌트
│   │   ├── layout/                # 레이아웃 컴포넌트
│   │   ├── management/            # 관리 페이지 컴포넌트
│   │   ├── master-data/          # 마스터 데이터 컴포넌트
│   │   ├── logs/                 # 로그 컴포넌트
│   │   ├── report/               # 리포트 컴포넌트
│   │   ├── schedule/             # 스케줄 컴포넌트
│   │   ├── system/               # 시스템 컴포넌트
│   │   └── ui/                   # Shadcn UI 컴포넌트
│   ├── lib/                      # 유틸리티 및 비즈니스 로직
│   │   ├── auth/                 # 인증 관련 로직
│   │   ├── dashboard/            # 대시보드 로직
│   │   ├── logs/                 # 로그 관련 로직
│   │   ├── management/           # 관리 기능 로직
│   │   ├── master-data/          # 마스터 데이터 로직
│   │   ├── report/               # 리포트 로직
│   │   ├── schedule/             # 스케줄 로직
│   │   ├── system/               # 시스템 로직
│   │   ├── logger/               # 로깅 유틸리티
│   │   ├── prisma.ts             # Prisma Client 인스턴스
│   │   └── utils.ts              # 공통 유틸리티
│   └── types/                    # TypeScript 타입 정의
├── prisma/                       # Prisma 설정
│   ├── schema.prisma             # 데이터베이스 스키마
│   ├── migrations/               # 마이그레이션 파일
│   └── seed.ts                   # 초기 데이터 시드
├── Dockerfile                    # App 컨테이너 빌드 설정
├── docker-compose.yml            # Docker Compose 설정
├── entrypoint.sh                 # 컨테이너 시작 스크립트
├── package.json                  # Node.js 의존성 및 스크립트
├── next.config.ts                # Next.js 설정
├── tsconfig.json                 # TypeScript 설정
├── tailwind.config.ts            # Tailwind CSS 설정
└── .env                          # 환경 변수 (로컬 개발용)
```

---

## 🚀 애플리케이션(App) 컨테이너 구조

### 컨테이너 정보

- **컨테이너 이름**: `adhub-app`
- **서비스 이름**: `app`
- **포트 매핑**: `5412:3000` (호스트:컨테이너)
- **이미지**: `Dockerfile`로 빌드된 커스텀 이미지
- **기반 이미지**: `node:22-alpine`

### 관련 파일

#### 1. **Dockerfile**
- 멀티 스테이지 빌드로 최적화된 이미지 생성
- **deps 단계**: 의존성 설치 (`npm ci`)
- **prisma 단계**: Prisma Client 생성
- **builder 단계**: Next.js 애플리케이션 빌드
- **runner 단계**: 프로덕션 런타임 환경

#### 2. **entrypoint.sh**
- 컨테이너 시작 시 자동 실행되는 스크립트
- 데이터베이스 연결 대기
- Prisma Client 생성
- 데이터베이스 마이그레이션 실행
- 초기 데이터 시드 (관리자 계정 생성)
- Next.js 앱 시작

#### 3. **package.json**
- 프로젝트 의존성 정의
- npm 스크립트 정의
  - `dev`: 개발 서버 실행
  - `build`: 프로덕션 빌드
  - `start`: 프로덕션 서버 시작
  - `prisma:migrate`: 마이그레이션 실행
  - `prisma:seed`: 시드 데이터 실행

#### 4. **src/app/**
- Next.js App Router 기반 페이지 및 라우트
- 각 페이지는 `page.tsx` 파일로 정의
- API 라우트는 `api/` 폴더에 정의

#### 5. **src/components/**
- React 컴포넌트
- 기능별로 폴더 구성
- UI 컴포넌트는 `ui/` 폴더에 Shadcn UI 기반

#### 6. **src/lib/**
- 비즈니스 로직 및 유틸리티 함수
- Server Actions (데이터 변경 작업)
- Prisma Client를 통한 데이터베이스 접근

#### 7. **next.config.ts**
- Next.js 설정 파일
- 빌드 옵션, 환경 변수 등 설정

### 빌드 프로세스

1. **의존성 설치**: `npm ci`로 정확한 버전 설치
2. **Prisma Client 생성**: `npx prisma generate`
3. **Next.js 빌드**: `npm run build`
4. **최적화**: 멀티 스테이지 빌드로 최종 이미지 크기 최소화

---

## 🗄️ 데이터베이스(PostgreSQL) 컨테이너 구조

### 컨테이너 정보

- **컨테이너 이름**: `ad-hub-postgres-database`
- **서비스 이름**: `postgres`
- **포트 매핑**: `6709:5432` (호스트:컨테이너)
- **이미지**: `postgres:15-alpine`
- **데이터 볼륨**: `./postgres-database` (로컬) 또는 `/volume1/docker/ad-hub/postgres-database` (Synology NAS)

### 관련 파일

#### 1. **prisma/schema.prisma**
- 데이터베이스 스키마 정의
- Prisma 모델 정의
- 주요 모델:
  - `User`: 사용자 정보
  - `UserAccessProfile`: 사용자 접근 권한 프로필
  - `Campaign`: 캠페인 데이터
  - `MasterDataItem`: 마스터 데이터
  - `ActivityLog`: 활동 로그
  - `Account`, `Session`, `VerificationToken`: NextAuth 관련

#### 2. **prisma/migrations/**
- 데이터베이스 마이그레이션 파일
- 스키마 변경 이력
- `prisma migrate deploy`로 적용

#### 3. **prisma/seed.ts**
- 초기 데이터 시드 스크립트
- 관리자 계정 생성
- 환경 변수로 관리자 정보 설정 가능

#### 4. **docker-compose.yml (postgres 서비스)**
- PostgreSQL 컨테이너 설정
- 환경 변수:
  - `POSTGRES_USER`: postgres
  - `POSTGRES_PASSWORD`: 환경 변수에서 가져옴
  - `POSTGRES_DB`: adhub
- Health check 설정

### 데이터 저장 위치

- **로컬 개발**: `./postgres-database/` (프로젝트 루트)
- **Synology NAS**: `/volume1/docker/ad-hub/postgres-database/`
- 데이터는 볼륨에 영구 저장되므로 컨테이너 재생성 시에도 유지됨

---

## 🔄 Docker 컨테이너 개별 업데이트

### App 컨테이너만 업데이트

애플리케이션 코드 변경 시 App 컨테이너만 재빌드하고 재시작합니다.

#### 방법 1: Docker Compose 사용 (권장)

```bash
# 프로젝트 디렉토리로 이동
cd /volume1/docker/ad-hub  # Synology NAS
# 또는
cd /path/to/ad-hub         # 로컬 개발

# App 컨테이너만 재빌드 및 재시작
docker compose up -d --build app

# 또는 단계별로 실행
docker compose stop app          # App 컨테이너 중지
docker compose build app         # App 이미지 재빌드
docker compose up -d app         # App 컨테이너 시작
```

#### 방법 2: Docker 명령어 직접 사용

```bash
# App 컨테이너 중지 및 제거
docker stop adhub-app
docker rm adhub-app

# 이미지 재빌드
docker compose build app

# 컨테이너 시작
docker compose up -d app
```

#### 방법 3: 코드 변경 후 자동 재시작

```bash
# 코드 변경 후
docker compose restart app
```

**⚠️ 주의사항:**
- App 컨테이너만 재시작하면 데이터베이스는 그대로 유지됩니다
- 마이그레이션이 필요한 경우 `entrypoint.sh`가 자동으로 실행하거나 수동 실행:
  ```bash
  docker exec -it adhub-app npx prisma migrate deploy
  ```

### 데이터베이스 컨테이너만 업데이트

데이터베이스 버전 업그레이드나 설정 변경 시 사용합니다.

#### 방법 1: Docker Compose 사용 (권장)

```bash
# PostgreSQL 컨테이너만 재시작
docker compose restart postgres

# 또는 재생성 (데이터는 볼륨에 보존됨)
docker compose up -d --force-recreate postgres
```

#### 방법 2: PostgreSQL 버전 업그레이드

```bash
# 1. 데이터베이스 백업 (중요!)
docker exec ad-hub-postgres-database pg_dump -U postgres adhub > backup_$(date +%Y%m%d).sql

# 2. docker-compose.yml에서 이미지 버전 변경
# 예: postgres:15-alpine → postgres:16-alpine

# 3. 컨테이너 재생성
docker compose stop postgres
docker compose rm -f postgres
docker compose up -d postgres

# 4. 백업에서 복원 (필요 시)
docker exec -i ad-hub-postgres-database psql -U postgres adhub < backup_YYYYMMDD.sql
```

**⚠️ 주의사항:**
- 데이터베이스 컨테이너 재시작 시 App 컨테이너는 자동으로 재연결됩니다
- 데이터는 볼륨에 저장되므로 컨테이너 재생성해도 데이터는 유지됩니다
- 버전 업그레이드 전 반드시 백업을 수행하세요

### 전체 컨테이너 업데이트

모든 컨테이너를 재빌드하고 재시작합니다.

```bash
# 전체 중지
docker compose down

# 전체 재빌드 및 시작
docker compose up -d --build

# 또는 단계별
docker compose build          # 모든 서비스 빌드
docker compose up -d          # 모든 서비스 시작
```

### 업데이트 시나리오별 가이드

#### 시나리오 1: 애플리케이션 코드 변경

```bash
# 1. 코드 변경 후
cd /volume1/docker/ad-hub

# 2. App 컨테이너만 재빌드
docker compose up -d --build app

# 3. 로그 확인
docker compose logs -f app
```

#### 시나리오 2: 데이터베이스 스키마 변경

```bash
# 1. prisma/schema.prisma 수정 후

# 2. 마이그레이션 파일 생성 (로컬에서)
npx prisma migrate dev --name your_migration_name

# 3. 마이그레이션 파일을 서버에 업로드

# 4. App 컨테이너에서 마이그레이션 실행
docker exec -it adhub-app npx prisma migrate deploy

# 또는 App 컨테이너 재시작 (entrypoint.sh가 자동 실행)
docker compose restart app
```

#### 시나리오 3: 환경 변수 변경

```bash
# 1. .env 파일 수정

# 2. App 컨테이너 재시작 (환경 변수 재로드)
docker compose restart app

# 또는 전체 재시작
docker compose down
docker compose up -d
```

#### 시나리오 4: 의존성 패키지 추가/변경

```bash
# 1. package.json 수정 후

# 2. App 컨테이너 재빌드 (의존성 재설치)
docker compose up -d --build app
```

---

## ⚙️ 주요 설정 파일 설명

### docker-compose.yml

Docker Compose 설정 파일로 다음 서비스를 정의합니다:

1. **init**: 볼륨 디렉토리 자동 생성
2. **app**: Next.js 애플리케이션
3. **postgres**: PostgreSQL 데이터베이스

**주요 설정:**
- 네트워크: `adhub-network` (bridge)
- 볼륨: 데이터베이스 데이터 영구 저장
- Health check: 컨테이너 상태 모니터링
- 의존성: App은 Postgres가 준비된 후 시작

### Dockerfile

멀티 스테이지 빌드로 최적화된 이미지를 생성합니다:

1. **deps**: 의존성 설치
2. **prisma**: Prisma Client 생성
3. **builder**: Next.js 빌드
4. **runner**: 프로덕션 런타임

**최적화 포인트:**
- Alpine Linux 기반으로 이미지 크기 최소화
- 멀티 스테이지 빌드로 불필요한 파일 제외
- 프로덕션 의존성만 포함

### entrypoint.sh

컨테이너 시작 시 자동 실행되는 스크립트입니다:

1. 데이터베이스 연결 대기
2. Prisma Client 생성
3. 데이터베이스 마이그레이션 실행
4. 초기 데이터 시드
5. Next.js 앱 시작

### .env

환경 변수 설정 파일 (Git에 커밋하지 않음):

```env
# 데이터베이스
DATABASE_URL="postgresql://postgres:password@postgres:5432/adhub?schema=public"
POSTGRES_PASSWORD="your_password"

# NextAuth
NEXTAUTH_SECRET="your_secret"
NEXTAUTH_URL="http://your-domain:5412"

# 시드 데이터
SEED_ADMIN_LOGIN_ID="admin"
SEED_ADMIN_PASSWORD="admin123"
```

---

## 📝 체크리스트

### App 컨테이너 업데이트 시

- [ ] 코드 변경 사항 확인
- [ ] 마이그레이션 필요 여부 확인
- [ ] 환경 변수 변경 여부 확인
- [ ] 의존성 변경 여부 확인
- [ ] 빌드 성공 확인
- [ ] 로그 확인
- [ ] 웹 브라우저 접속 테스트

### 데이터베이스 컨테이너 업데이트 시

- [ ] 데이터베이스 백업 수행
- [ ] 볼륨 경로 확인
- [ ] 환경 변수 확인
- [ ] 컨테이너 상태 확인
- [ ] App 컨테이너 연결 확인
- [ ] 데이터 무결성 확인

---

## 🔗 관련 문서

- [Docker 배포 가이드](./DOCKER_DEPLOYMENT_GUIDE.md)
- [서버 마이그레이션 가이드](./MIGRATION_GUIDE.md)

---

**마지막 업데이트**: 2025-01-15


